const api = process.env.SCHOLARQL_API_URL ?? "http://127.0.0.1:8000";
type Trend = { topic_id: string; topic_name: string; publication_year: number; paper_count: number };

export default async function TrendsPage() {
  let items: Trend[] = [];
  let unavailable = false;
  try {
    const response = await fetch(`${api}/trends?year_from=2018&year_to=2024&limit=40`, { next: { revalidate: 300 } });
    if (!response.ok) throw new Error("Trend API unavailable");
    ({ items } = await response.json());
  } catch {
    unavailable = true;
  }
  const topicNames = [...new Set(items.map((item) => item.topic_name))];
  const years = [...new Set(items.map((item) => item.publication_year))].sort();
  const max = Math.max(1, ...items.map((item) => item.paper_count));
  return (
    <section>
      <div className="eyebrow">Research landscape</div>
      <h1>Topic trends</h1>
      <p className="lede">Paper counts by OpenAlex topic and publication year in the loaded corpus.</p>
      {unavailable && <p className="notice">Trend data is not available yet. Load the dataset and refresh the analytics views.</p>}
      {!unavailable && items.length === 0 && <p className="notice">No trend data yet. Load papers and run <code>CALL refresh_analytics()</code>.</p>}
      {items.length > 0 && <div className="table-wrap"><table>
        <thead><tr><th scope="col">Topic</th>{years.map((year) => <th scope="col" key={year}>{year}</th>)}</tr></thead>
        <tbody>{topicNames.map((name) => <tr key={name}>
          <th scope="row">{name}</th>
          {years.map((year) => {
            const count = items.find((item) => item.topic_name === name && item.publication_year === year)?.paper_count ?? 0;
            return <td key={year}><span className="heat" style={{ opacity: count === 0 ? 0.12 : 0.28 + 0.72 * count / max }}>{count || "—"}</span></td>;
          })}
        </tr>)}</tbody>
      </table></div>}
    </section>
  );
}
