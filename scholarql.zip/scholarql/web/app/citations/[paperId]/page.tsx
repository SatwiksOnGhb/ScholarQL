import Link from "next/link";
import CitationGraph from "../CitationGraph";

const api = process.env.SCHOLARQL_API_URL ?? "http://127.0.0.1:8000";
type CitationResponse = { root_paper_id: string; depth: number; truncated: boolean; edges: { level: number; citing_id: string; cited_id: string; citing_title: string; cited_title: string }[] };

export default async function CitationPage({ params, searchParams }: { params: Promise<{ paperId: string }>; searchParams: Promise<{ depth?: string }> }) {
  const { paperId } = await params;
  const queryParams = await searchParams;
  const parsedDepth = Number(queryParams.depth ?? "3");
  const depth = Number.isInteger(parsedDepth) ? Math.max(1, Math.min(parsedDepth, 5)) : 3;
  const response = await fetch(`${api}/citations/${encodeURIComponent(paperId)}?depth=${depth}`, { next: { revalidate: 60 } });
  if (!response.ok) throw new Error(response.status === 404 ? "Paper not found" : "Could not load citation graph");
  const graph: CitationResponse = await response.json();
  const nodeMap = new Map<string, { id: string; name: string; level: number }>();
  for (const edge of graph.edges) {
    if (!nodeMap.has(edge.citing_id)) nodeMap.set(edge.citing_id, { id: edge.citing_id, name: edge.citing_title, level: edge.level });
    if (!nodeMap.has(edge.cited_id)) nodeMap.set(edge.cited_id, { id: edge.cited_id, name: edge.cited_title, level: edge.level });
  }
  return (
    <section>
      <div className="eyebrow">Citation explorer</div>
      <h1>Citation chain</h1>
      <p className="lede">Starting paper: <Link href={`/papers/${encodeURIComponent(graph.root_paper_id)}`}>{graph.root_paper_id}</Link>. Showing outgoing references through {graph.depth} levels.</p>
      <form className="filters compact" action={`/citations/${encodeURIComponent(paperId)}`}>
        <label>Traversal depth<input name="depth" type="number" min="1" max="20" defaultValue={depth} /></label>
        <button type="submit">Update graph</button>
      </form>
      {graph.edges.length === 0 ? <p className="notice">No in-scope citation links were found within this depth.</p> : (
        <>
        {graph.truncated && <p className="notice">Showing the first 2,000 citation links. Reduce the traversal depth to see a smaller slice.</p>}
        <CitationGraph
          nodes={[...nodeMap.values()]}
          links={graph.edges.map((edge) => ({ source: edge.citing_id, target: edge.cited_id }))}
        />
        <ol className="citation-list">
          {graph.edges.map((edge, index) => (
            <li className="citation-edge" key={`${edge.citing_id}-${edge.cited_id}-${index}`}>
              <span className="level">Level {edge.level}</span>
              <Link href={`/papers/${encodeURIComponent(edge.citing_id)}`}>{edge.citing_title}</Link>
              <span className="arrow" aria-label="cites">cites ↓</span>
              <Link href={`/papers/${encodeURIComponent(edge.cited_id)}`}>{edge.cited_title}</Link>
            </li>
          ))}
        </ol>
        </>
      )}
    </section>
  );
}
