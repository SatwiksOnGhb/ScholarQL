from fastapi import APIRouter, HTTPException, Query

from app.db import pool

router = APIRouter(prefix="/citations", tags=["citations"])


@router.get("/{paper_id}")
async def get_citation_graph(paper_id: str, depth: int = Query(default=2, ge=1, le=5)):
    async with pool.connection() as connection:
        exists = await (await connection.execute("SELECT 1 FROM paper WHERE paper_id = %s", (paper_id,))).fetchone()
        if exists is None:
            raise HTTPException(status_code=404, detail="Paper not found")
        rows = await (await connection.execute(
            """SELECT chain.level, chain.citing_id, chain.cited_id, chain.path,
                      source.title AS citing_title, target.title AS cited_title
               FROM citation_chain(%s, %s) chain
               JOIN paper source ON source.paper_id = chain.citing_id
               JOIN paper target ON target.paper_id = chain.cited_id
               ORDER BY chain.level, chain.citing_id, chain.cited_id
               LIMIT 2000""",
            (paper_id, depth),
        )).fetchall()
    return {"root_paper_id": paper_id, "depth": depth, "truncated": len(rows) == 2000, "edges": rows}
