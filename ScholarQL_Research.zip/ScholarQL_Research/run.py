"""Start the ScholarQL API and its bundled frontend."""
import argparse
from threading import Thread
from time import sleep
from urllib.error import URLError
from urllib.request import urlopen
from webbrowser import open as open_browser

import uvicorn


def open_when_ready(port):
    site = f"http://127.0.0.1:{port}"
    for _ in range(80):
        try:
            with urlopen(site + "/api/status", timeout=1):
                open_browser(site)
                return
        except (URLError, TimeoutError):
            sleep(.25)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--open", action="store_true", help="Open the website once it responds.")
    args = parser.parse_args()
    if args.open:
        Thread(target=open_when_ready, args=(args.port,), daemon=True).start()
    uvicorn.run("scholarql.api:app", host=args.host, port=args.port)
