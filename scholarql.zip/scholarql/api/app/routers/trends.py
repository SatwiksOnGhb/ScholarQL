from fastapi import APIRouter, HTTPException, Query

from app.db import pool

router = APIRouter(prefix="/trends", tags=["trends"])


@router.get("")
async def get_trends(
    year_from: int = Query(default=2018, ge=1800, le=2100),
    year_to: int = Query(default=2024, ge=1800, le=2100),
    topic_id: str | None = None,
    limit: int = Query(default=40, ge=1, le=100),
):
    if year_from > year_to:
        raise HTTPException(status_code=422, detail="year_from must be <= year_to")
    sql = """WITH selected_topics AS (
                 SELECT topic_id
                 FROM topic_year_trends
                 WHERE publication_year BETWEEN %s AND %s
                   AND (%s::text IS NULL OR topic_id = %s)
                 GROUP BY topic_id
                 ORDER BY sum(paper_count) DESC, topic_id
                 LIMIT %s
             )
             SELECT trends.topic_id, trends.topic_name, trends.publication_year, trends.paper_count
             FROM topic_year_trends trends
             JOIN selected_topics USING (topic_id)
             WHERE trends.publication_year BETWEEN %s AND %s
             ORDER BY trends.topic_name, trends.publication_year"""
    async with pool.connection() as connection:
        rows = await (await connection.execute(sql, (year_from, year_to, topic_id, topic_id, limit, year_from, year_to))).fetchall()
    return {"items": rows, "year_from": year_from, "year_to": year_to, "topic_limit": limit}
