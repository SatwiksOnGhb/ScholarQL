"use client";

import dynamic from "next/dynamic";

const ForceGraph2D = dynamic(() => import("react-force-graph-2d"), {
  ssr: false,
  loading: () => <div className="graph-loading" role="status">Loading citation graph…</div>,
});

export type CitationNode = { id: string; name: string; level: number };
export type CitationLink = { source: string; target: string };

export default function CitationGraph({ nodes, links }: { nodes: CitationNode[]; links: CitationLink[] }) {
  return (
    <div className="graph-frame" aria-label="Interactive citation graph. Drag to rearrange, scroll to zoom, click a paper to open its record.">
      <ForceGraph2D
        graphData={{ nodes, links }}
        width={900}
        height={520}
        nodeId="id"
        nodeLabel="name"
        nodeAutoColorBy="level"
        linkDirectionalArrowLength={5}
        linkDirectionalArrowRelPos={1}
        linkColor={() => "#91aaa8"}
        onNodeClick={(node) => {
          window.location.assign(`/papers/${encodeURIComponent(String(node.id))}`);
        }}
      />
    </div>
  );
}
