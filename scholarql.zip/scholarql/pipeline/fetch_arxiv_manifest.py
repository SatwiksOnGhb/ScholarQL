"""Harvest an auditable cs.LG/cs.AI arXiv ID manifest for 2018-2024."""

from __future__ import annotations

import argparse
import asyncio
import csv
import re
import xml.etree.ElementTree as ET
from pathlib import Path

import httpx

API = "https://export.arxiv.org/api/query"
ATOM = "http://www.w3.org/2005/Atom"
ARXIV = "http://arxiv.org/schemas/atom"
OPEN_SEARCH = "http://a9.com/-/spec/opensearch/1.1/"


async def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("data/arxiv_manifest.csv"))
    parser.add_argument("--start-year", type=int, default=2018)
    parser.add_argument("--end-year", type=int, default=2024)
    args = parser.parse_args()
    if args.start_year > args.end_year:
        parser.error("start year must be <= end year")

    rows: dict[str, dict[str, str]] = {}
    async with httpx.AsyncClient(timeout=60, headers={"User-Agent": "ScholarQL/0.1 (academic DBMS project)"}) as client:
        for year in range(args.start_year, args.end_year + 1):
            query = f"(cat:cs.LG OR cat:cs.AI) AND submittedDate:[{year}01010000 TO {year}12312359]"
            start = 0
            while True:
                if start:
                    await asyncio.sleep(3)
                response = await client.get(
                    API,
                    params={"search_query": query, "start": start, "max_results": 2000, "sortBy": "submittedDate", "sortOrder": "ascending"},
                )
                response.raise_for_status()
                root = ET.fromstring(response.text)
                entries = root.findall(f"{{{ATOM}}}entry")
                for entry in entries:
                    raw_id = entry.findtext(f"{{{ATOM}}}id", default="")
                    match = re.search(r"arxiv\.org/abs/(.+?)(?:v\d+)?$", raw_id)
                    if not match:
                        continue
                    paper_id = match.group(1)
                    published = entry.findtext(f"{{{ATOM}}}published", default="")[:10]
                    if not published or not f"{args.start_year}" <= published[:4] <= f"{args.end_year}":
                        continue
                    primary = entry.find(f"{{{ARXIV}}}primary_category")
                    categories = {
                        item.attrib["term"]
                        for item in entry.findall(f"{{{ATOM}}}category")
                        if item.attrib.get("term")
                    }
                    rows[paper_id] = {
                        "arxiv_id": paper_id,
                        "first_submission_date": published,
                        "primary_category": primary.attrib.get("term", "") if primary is not None else "",
                        "categories": "|".join(sorted(categories)),
                    }
                total = int(root.findtext(f"{{{OPEN_SEARCH}}}totalResults", default="0"))
                print(f"arXiv {year}: retrieved {len(entries)} rows at offset {start} of {total}")
                start += len(entries)
                if not entries or start >= total:
                    break

    args.out.parent.mkdir(parents=True, exist_ok=True)
    tmp = args.out.with_suffix(args.out.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8", newline="") as output:
        writer = csv.DictWriter(output, fieldnames=["arxiv_id", "first_submission_date", "primary_category", "categories"])
        writer.writeheader()
        for key in sorted(rows):
            writer.writerow(rows[key])
    tmp.replace(args.out)
    print(f"Wrote {len(rows)} unique arXiv IDs to {args.out}")


if __name__ == "__main__":
    asyncio.run(main())
