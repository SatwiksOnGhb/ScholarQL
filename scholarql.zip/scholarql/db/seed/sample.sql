BEGIN;
INSERT INTO institution (institution_id, name, country_code) VALUES
('I-SAMPLE-1', 'Example Institute of Technology', 'US'),
('I-SAMPLE-2', 'Example University', 'GB');
INSERT INTO venue (venue_id, name, venue_type) VALUES
('V-SAMPLE-1', 'Example ML Conference', 'conference'),
('V-SAMPLE-2', 'Example AI Journal', 'journal');
INSERT INTO author (author_id, name, h_index) VALUES
('A-SAMPLE-1', 'Ada Example', 12),
('A-SAMPLE-2', 'Lin Example', 8),
('A-SAMPLE-3', 'Sam Example', 4);
INSERT INTO topic (topic_id, name, level) VALUES
('T-SAMPLE-1', 'Machine learning', 2),
('T-SAMPLE-2', 'Artificial intelligence', 2);
INSERT INTO paper (paper_id, title, publication_year, arxiv_id, venue_id) VALUES
('P-SAMPLE-1', 'A Sample Method for Learning', 2021, '2101.00001', 'V-SAMPLE-1'),
('P-SAMPLE-2', 'An Example of Robust Learning', 2022, '2202.00002', 'V-SAMPLE-1'),
('P-SAMPLE-3', 'A Survey of Example AI Systems', 2023, '2303.00003', 'V-SAMPLE-2');
INSERT INTO authorship (paper_id, author_id, author_order) VALUES
('P-SAMPLE-1', 'A-SAMPLE-1', 1), ('P-SAMPLE-1', 'A-SAMPLE-2', 2),
('P-SAMPLE-2', 'A-SAMPLE-1', 1), ('P-SAMPLE-2', 'A-SAMPLE-3', 2),
('P-SAMPLE-3', 'A-SAMPLE-2', 1);
INSERT INTO author_affiliation (paper_id, author_id, institution_id) VALUES
('P-SAMPLE-1', 'A-SAMPLE-1', 'I-SAMPLE-1'), ('P-SAMPLE-1', 'A-SAMPLE-2', 'I-SAMPLE-2'),
('P-SAMPLE-2', 'A-SAMPLE-1', 'I-SAMPLE-1'), ('P-SAMPLE-2', 'A-SAMPLE-3', 'I-SAMPLE-1'),
('P-SAMPLE-3', 'A-SAMPLE-2', 'I-SAMPLE-2');
INSERT INTO paper_topic (paper_id, topic_id, relevance, is_primary) VALUES
('P-SAMPLE-1', 'T-SAMPLE-1', 0.92, true),
('P-SAMPLE-2', 'T-SAMPLE-1', 0.88, true),
('P-SAMPLE-3', 'T-SAMPLE-2', 0.86, true);
INSERT INTO citation (citing_id, cited_id) VALUES
('P-SAMPLE-2', 'P-SAMPLE-1'), ('P-SAMPLE-3', 'P-SAMPLE-1'), ('P-SAMPLE-3', 'P-SAMPLE-2');
CALL refresh_analytics();
COMMIT;
