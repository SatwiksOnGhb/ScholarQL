from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
import os
from pathlib import Path

from psycopg.rows import dict_row
from psycopg_pool import AsyncConnectionPool
from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parents[2] / ".env")
DATABASE_URL = os.environ["SCHOLARQL_DATABASE_URL"]
pool = AsyncConnectionPool(
    conninfo=DATABASE_URL,
    min_size=1,
    max_size=10,
    kwargs={"row_factory": dict_row, "autocommit": True},
    open=False,
)


@asynccontextmanager
async def lifespan_pool() -> AsyncIterator[None]:
    await pool.open()
    try:
        yield
    finally:
        await pool.close()
