# ScholarQL - Person A: relational core

This folder contains the Person A work from the supplied project plan. The existing workspace root is a separate Deposit360 project, so this work is isolated here and does not change that app.

## Included

- PostgreSQL schema for papers, authors, venues, institutions, topics, authorship, affiliations, paper-topic links, and citations.
- Constraints, foreign-key and trigram indexes, citation-count maintenance, citation traversal and coauthor functions, materialized trend/author views, and a PageRank procedure.
- A transaction-oriented bulk-load entry point and staging format for OpenAlex/Semantic Scholar records.
- A reproducible benchmark SQL file for recording `EXPLAIN (ANALYZE, BUFFERS, FORMAT JSON)` before and after the secondary indexes.
- Current source/API notes in `docs/research-notes.md`.

## Apply the schema

Use PostgreSQL 16 or newer and dbmate. For a fresh database, create the owner role and database as a PostgreSQL administrator:

```powershell
psql -U postgres -c "CREATE ROLE scholarql_owner LOGIN PASSWORD 'replace-with-owner-password';"
psql -U postgres -c "CREATE DATABASE scholarql OWNER scholarql_owner;"
```

Copy `.env.example` to `.env`, set unique owner/reader passwords, then run from this folder:

```powershell
dbmate up
```

Make `DATABASE_URL` use the owner login. Run `uv sync` to install the Python project dependencies.

For a least-privilege API reader, run the migration as the database owner and then:

```powershell
psql "$env:DATABASE_URL" -v ON_ERROR_STOP=1 -f db/roles/reader.sql
```

Set the shell variable `SCHOLARQL_READER_PASSWORD` to the same reader password before applying the role script. `DATABASE_URL` is the migration/pipeline owner connection; `SCHOLARQL_DATABASE_URL` is the API's read-only connection. Do not commit `.env` or secrets.

## Data pipeline

The pipeline is in `pipeline/`. First run `uv run python pipeline/fetch_arxiv_manifest.py` to record arXiv IDs matching `cs.LG` or `cs.AI` for 2018-2024. For the planned initial 1,000-work seed, run `uv run python pipeline/fetch_openalex.py data/arxiv_manifest.csv --limit 1000`; for the planned 50K corpus, run it with `--limit 50000`. Both subsets are deterministic and stratified by first-submission year and category. Review the manifest and API budget before starting a full run. Store OpenAlex keys in `OPENALEX_API_KEY`; a verified free key enables cursor paging. The OpenAlex `ids.arxiv` filter used by the lookup is currently supported in the API implementation but is not listed among the public work filters, so verify a small sample lookup before the full harvest. Run optional enrichment with `uv run python pipeline/enrich_semantic_scholar.py data/openalex_works.jsonl`; set `SEMANTIC_SCHOLAR_API_KEY` when available. Load relational records with `uv run python pipeline/load_openalex.py data/openalex_works.jsonl --semantic-scholar data/semantic_scholar_enrichment.jsonl`; generate the NoSQL handoff with `uv run python pipeline/extract_papers_content.py data/openalex_works.jsonl --semantic-scholar data/semantic_scholar_enrichment.jsonl`.

Run the API from `api/` with `uv run uvicorn app.main:app --reload`. It reads the `SCHOLARQL_DATABASE_URL` reader account from the project `.env`.

Run the web app from `web/` with `pnpm install` followed by `pnpm dev`; it uses `http://127.0.0.1:8000` by default for the API.

Records are staged and loaded in batches in one transaction per batch. The proposed arXiv subset should be selected using arXiv category membership (`cs.LG` or `cs.AI`) and years 2018-2024, then enriched from OpenAlex. OpenAlex topic labels are not equivalent to arXiv category membership; the final selection logic must preserve arXiv IDs so that this scope can be audited.

## SQL functions

- `citation_chain(paper_id, depth)` returns outgoing citation paths up to the requested depth, protecting against cycles.
- `coauthors(author_id)` returns the author's coauthors from shared papers.
- `compute_pagerank(iterations, damping)` updates `paper.pagerank_score` using the in-scope citation graph.
- `refresh_analytics()` refreshes the topic trend and author-stat materialized views.

The benchmark queries include lookup, joins, aggregation, recursive traversal, and fuzzy author linking. For a study, load one dataset and use the same server, parameters, and cache method: run `db/bench/without_secondary_indexes.sql`, capture `EXPLAIN (ANALYZE, BUFFERS)` and run `python db/bench/latency_benchmark.py --label baseline`; then run `db/bench/with_secondary_indexes.sql`, `ANALYZE`, recapture plans, and run it with `--label indexed`. Capture the database version, hardware, row counts, and warm/cold cache method. The scripts store measured results; the report must not claim an improvement until the runs have been completed.

## Contract to the rest of ScholarQL

Canonical IDs are OpenAlex IDs (stored as text). `papers_content.jsonl` should use the same `paper_id` and be produced from the same paper batches. API and UI integration remain with Person C's shared skeleton; Person A's route/page work should follow the frozen OpenAPI contract once that skeleton is available.
