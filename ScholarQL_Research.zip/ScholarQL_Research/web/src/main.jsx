import React, { useEffect, useRef, useState } from 'react'
import { createRoot } from 'react-dom/client'
import {
  ArrowDownToLine, ArrowDownRight, ArrowLeft, ArrowRight, ArrowUpRight, BarChart3, BookOpen,
  Check, ChevronDown, CircleHelp, Code2, Copy, Database, FileCode2, FileText, GitFork, History,
  Layers3, LoaderCircle, Network, Search, Send, SlidersHorizontal, Terminal, X,
} from 'lucide-react'
import './styles.css'

const routes = {
  auto: 'Automatic', sql: 'SQL', semantic: 'Document search', hybrid: 'Combined',
}
const samples = [
  { kind: 'Combined', icon: Layers3, text: 'Find papers about adapting language models on a small GPU published since 2023.' },
  { kind: 'SQL · aggregation', icon: Database, text: 'Top 5 venues by average citations since 2021' },
  { kind: 'SQL · recursive', icon: GitFork, text: 'Show the citation chain from "Mistral 7B" up to depth 2' },
  { kind: 'Document search', icon: Search, text: 'Explain how diffusion models generate images' },
]
const nav = [
  ['workbench', 'Query workbench', Terminal], ['papers', 'Paper library', BookOpen],
  ['citations', 'Citation explorer', Network], ['trends', 'Publication trends', BarChart3],
  ['evaluation', 'Evaluation', FileCode2], ['history', 'Query history', History],
]
const format = (x) => x == null ? '—' : new Intl.NumberFormat('en').format(x)
const number = (x, places = 2) => x == null ? '—' : Number(x).toFixed(places)
const rowLabel = (key) => key.replaceAll('_', ' ').replace(/^./, (c) => c.toUpperCase())
const arxivHref = (id) => /^\d{4}\.\d{4,5}$/.test(id ?? '') ? `https://arxiv.org/abs/${id}` : null
const fileHref = (name) => `/api/artifacts/${name}`
const graphRoot = 'W4401306886'

async function api(path, options) {
  const response = await fetch(`/api${path}`, options)
  if (!response.ok) {
    const body = await response.json().catch(() => ({}))
    throw Error(typeof body.detail === 'string' ? body.detail : 'The request could not be completed.')
  }
  return response.json()
}

function useResource(path) {
  const [state, setState] = useState({ data: null, error: '', loading: true })
  useEffect(() => {
    if (!path) return undefined
    const ctrl = new AbortController()
    setState({ data: null, error: '', loading: true })
    api(path, { signal: ctrl.signal })
      .then((data) => setState({ data, error: '', loading: false }))
      .catch((error) => {
        if (!ctrl.signal.aborted) setState({ data: null, error: error.message, loading: false })
      })
    return () => ctrl.abort()
  }, [path])
  return state
}

function Mark() {
  return <div className="mark"><Network size={23} strokeWidth={2.2} aria-hidden="true" /></div>
}
function Badge({ children, tone = 'blue' }) {
  return <span className={`badge badge-${tone}`}>{children}</span>
}
function Busy({ text = 'Loading…' }) {
  return <div className="empty" role="status"><LoaderCircle className="spin" size={19} />{text}</div>
}
function Empty({ children, icon: Icon = CircleHelp }) {
  return <div className="empty"><Icon size={18} />{children}</div>
}
function PageHeader({ label, title, text }) {
  return <header className="page-header"><div className="eyebrow">{label}</div><h1>{title}</h1><p>{text}</p></header>
}
function LinkFile({ name, children }) {
  return <a className="secondary-button small-button" href={fileHref(name)}><ArrowDownToLine size={15} />{children}</a>
}
function display(value) {
  if (value == null) return '—'
  if (typeof value === 'object') return JSON.stringify(value)
  return String(value)
}
function downloadCSV(result) {
  const quoteCSV = (value) => {
    const cell = value == null ? '' : display(value)
    const safe = typeof value === 'string' && /^[\t\r\n ]*[=+\-@]/.test(cell) ? "'" + cell : cell
    return '"' + safe.replaceAll('"', '""') + '"'
  }
  const columns = result.route === 'sql' ? result.columns : ['paper_id', 'title', 'publication_year', 'score']
  const rows = result.route === 'sql' ? result.rows : result.papers.map((paper) => columns.map((key) => paper[key]))
  const payload = [columns, ...rows].map((row) => row.map(quoteCSV).join(',')).join('\r\n')
  const url = URL.createObjectURL(new Blob([payload], { type: 'text/csv;charset=utf-8' }))
  const a = document.createElement('a')
  a.href = url
  a.download = 'scholarql-query.csv'
  a.click()
  setTimeout(() => URL.revokeObjectURL(url), 1000)
}

function Pipeline({ route }) {
  return <div className="pipeline" aria-label="Query execution flow">
    <div className="pipe-start"><Search size={15} /> Question</div>
    <div className="pipe-wire" />
    <div className="pipe-choices">
      <div className={route === 'semantic' ? 'pipe-node muted-node' : 'pipe-node'}><Database size={16} /> Relational</div>
      <div className={route === 'sql' ? 'pipe-node muted-node' : 'pipe-node'}><Layers3 size={16} /> Documents</div>
    </div>
    <div className="pipe-wire" />
    <div className="pipe-end"><FileText size={15} /> Evidence</div>
  </div>
}
function SQLBlock({ sql }) {
  const [copied, setCopied] = useState(false)
  const lines = sql.split('\n')
  const keyword = /\b(SELECT|FROM|WHERE|ORDER BY|BETWEEN|ORDER|GROUP BY|RECURSIVE|EXISTS|AND|JOIN|USING|NOT|AS|ASC|DESC|ON|LIMIT|WITH|UNION|HAVING|DISTINCT)\b/gi
  return <div className="codebox">
    <div className="code-toolbar"><span><Code2 size={15} /> SQL</span>
      <button className="icon-button" type="button" aria-label="Copy SQL" onClick={async () => {
        try { await navigator.clipboard.writeText(sql); setCopied(true); setTimeout(() => setCopied(false), 1600) }
        catch { setCopied(false) }
      }}>{copied ? <Check size={16} /> : <Copy size={16} />}</button>
    </div>
    <pre><code>{lines.map((line, n) => <span className="code-line" key={n}>
      <i aria-hidden="true">{n + 1}</i><span>{line.split(keyword).map((part, j) =>
        j % 2 ? <b key={j}>{part}</b> : <React.Fragment key={j}>{part}</React.Fragment>)}</span>
    </span>)}</code></pre>
  </div>
}
function Evidence({ result, status }) {
  if (!result) return <aside className="panel inspector">
    <div className="panel-title"><Code2 size={19} /><h2>Execution evidence</h2></div>
    <Empty>Run a question to inspect its execution.</Empty>
  </aside>
  const steps = [
    ['Route', routes[result.route]], ['Relational engine', result.sql_engine],
    ...(result.retriever ? [['Ranker', result.retriever]] : []),
    ...(result.candidates != null ? [['SQL candidates', format(result.candidates)], ['With documents', format(result.documents_in_scope)]] : []),
    ...(result.model ? [['Model', result.model]] : []),
    ['Latency', `${number(result.latency_ms)} ms`],
  ]
  return <aside className="panel inspector">
    <div className="panel-title"><Code2 size={19} /><h2>Execution evidence</h2></div>
    <dl className="facts">{steps.map(([name, value]) => <div key={name}><dt>{name}</dt><dd>{value}</dd></div>)}</dl>
    {result.filters?.length > 0 && <div className="filter-readout">
      <span className="eyebrow">Applied filters</span><div>{result.filters.map((x) => <Badge key={x}>{x}</Badge>)}</div>
    </div>}
    {result.concept && <div className="concept-readout"><span className="eyebrow">Ranked concept</span><p>{result.concept}</p></div>}
    {result.sql && <SQLBlock sql={result.sql} />}
    <p className="scope-note">{result.planner_checked ? 'PostgreSQL planner checked. ' : ''}{status?.scope || 'Results reflect the selected database.'}</p>
    {result.attempts?.length > 1 && <div className="attempts">{result.attempts.map((attempt, i) =>
      <p key={i}>Attempt {i + 1} · {attempt.status}{attempt.diagnostic && ` · ${attempt.diagnostic}`}</p>)}</div>}
  </aside>
}
function Results({ result, pending, error, openPaper }) {
  const count = (result?.route === 'sql' ? result?.rows?.length : result?.papers?.length) ?? 0
  return <section className="panel results" aria-busy={pending}>
    <div className="panel-title result-heading" aria-live="polite">
      <div><h2>Results</h2>{result?.status === 'answered' && <Badge tone="success">{count} {result.route === 'sql' ? 'rows' : 'papers'}</Badge>}</div>
      {count > 0 && <button className="secondary-button small-button" onClick={() => downloadCSV(result)}><ArrowDownToLine size={15} /> CSV</button>}
    </div>
    {error && <div className="notice" role="alert">{error}</div>}
    {pending && <Busy text="Running query…" />}
    {!pending && !error && !result && <Empty icon={Search}>Ask a question or run an example.</Empty>}
    {!pending && !error && result?.status === 'no_results' && <Empty icon={Search}>No results matched this question in the current corpus.</Empty>}
    {!pending && !error && result?.diagnostic && <div className="notice" role="status">{result.diagnostic}</div>}
    {!pending && !error && result?.status === 'answered' && result.route === 'sql' &&
      <DataTable columns={result.columns} rows={result.rows} openPaper={openPaper} />}
    {!pending && !error && result?.status === 'answered' && result.route !== 'sql' &&
      <div className="result-list">{result.papers.map((paper, i) =>
        <article className="ranked-paper" key={paper.paper_id}>
          <div className="rank-number">{String(i + 1).padStart(2, '0')}</div>
          <div className="rank-body">
            <div className="paper-meta">{paper.publication_year ?? 'Year unavailable'}{paper.arxiv_id && ` · arXiv:${paper.arxiv_id}`}</div>
            <button className="paper-title" onClick={() => openPaper(paper.paper_id)}>{paper.title}<ArrowUpRight size={17} /></button>
            <p>{(paper.abstract ?? '').slice(0, 260)}{paper.abstract?.length > 260 ? '…' : ''}</p>
            <div className="rank-tags">{paper.categories?.slice(0, 3).map((cat) => <Badge key={cat} tone="plain">{cat}</Badge>)}</div>
          </div>
          <div className="score"><span>{number(paper.score, 3)}</span><small>score</small></div>
        </article>)}</div>}
    {result?.truncated && <p className="table-note">Showing the first {count} rows. Refine the query for more specific results.</p>}
  </section>
}
function DataTable({ columns, rows, openPaper }) {
  const idIndex = columns.indexOf('paper_id')
  return <div className="table-scroll" tabIndex="0" aria-label="Result table">
    <table><thead><tr>{columns.map((key, i) => <th key={i}>{rowLabel(key)}</th>)}</tr></thead>
      <tbody>{rows.map((row, i) => <tr key={i}>{row.map((value, j) =>
        <td key={j}>{openPaper && idIndex !== -1 && (columns[j] === 'title' || (j === idIndex && !columns.includes('title'))) ?
          <button className="table-link" onClick={() => openPaper(row[idIndex])}>{display(value)}</button> : display(value)}</td>)}</tr>)}</tbody>
    </table>
  </div>
}
function Workbench({ status, openPaper, active, edit }) {
  const [question, setQuestion] = useState(samples[0].text)
  const [route, setRoute] = useState('auto')
  const [generator, setGenerator] = useState('local')
  const [strategy, setStrategy] = useState('few_shot_correction')
  const [showSettings, setShowSettings] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [pending, setPending] = useState(false)
  const autoRan = useRef(false)
  const request = useRef(null)
  const textarea = useRef(null)

  async function submit(text = question, currentRoute = route, currentGenerator = generator) {
    if (text.trim().length < 3) return
    request.current?.abort()
    const ctrl = new AbortController()
    request.current = ctrl
    setPending(true); setError(''); setResult(null)
    try {
      const value = await api('/query', { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ question: text.trim(), route: currentRoute, generator: currentGenerator, strategy, k: 8 }),
        signal: ctrl.signal })
      if (!ctrl.signal.aborted) setResult(value)
    } catch (err) {
      if (!ctrl.signal.aborted) setError(err.message)
    } finally {
      if (!ctrl.signal.aborted) setPending(false)
    }
  }
  useEffect(() => {
    if (status?.scope && !autoRan.current) {
      autoRan.current = true
      submit(samples[0].text, 'auto', 'local')
    }
  }, [status])
  useEffect(() => {
    if (edit) { setQuestion(edit.text); setRoute('auto'); textarea.current?.focus() }
  }, [edit])

  return <div hidden={!active}>
    <section className="hero">
      <div className="hero-copy"><div className="hero-label"><span /> Research workbench</div>
        <h1>Search the literature.<br />Trace the evidence.</h1>
        <p>Ask about papers, citations, or research concepts. See the query and source records behind each answer.</p>
      </div>
      <Pipeline route={result?.route} />
    </section>
    <form className="panel query-panel" onSubmit={(e) => { e.preventDefault(); submit() }}>
      <div className="panel-title query-title"><div><Terminal size={19} /><h2>Ask ScholarQL</h2></div>
        <button className="text-button" type="button" aria-expanded={showSettings} onClick={() => setShowSettings(!showSettings)}>
          <SlidersHorizontal size={15} /> Query settings <ChevronDown size={13} />
        </button></div>
      <label className="visually-hidden" htmlFor="query-input">Research question</label>
      <textarea ref={textarea} id="query-input" value={question} onChange={(e) => setQuestion(e.target.value)}
        maxLength={900} placeholder="Ask a question about the research corpus…" rows={2}
        onKeyDown={(e) => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !pending) submit() }} />
      <div className={`query-controls ${showSettings ? 'show-settings' : ''}`}>
        <label>Route<select value={route} onChange={(e) => setRoute(e.target.value)}>
          {Object.entries(routes).map(([name, label]) => <option key={name} value={name}>{label}</option>)}</select></label>
        {showSettings && <label>SQL generator<select value={generator} onChange={(e) => setGenerator(e.target.value)}>
          <option value="local">Local patterns</option><option disabled={!status?.providers?.gemini} value="gemini">Gemini</option>
          <option disabled={!status?.providers?.groq} value="groq">Groq</option></select></label>}
        {showSettings && generator !== 'local' && <label>Strategy<select value={strategy} onChange={(e) => setStrategy(e.target.value)}>
          <option value="zero_shot">Zero-shot</option><option value="few_shot">Few-shot</option>
          <option value="few_shot_correction">Few-shot + correction</option></select></label>}
        <button type="submit" className="primary-button run" disabled={pending || question.trim().length < 3}>
          {pending ? <LoaderCircle size={16} className="spin" /> : <Send size={15} />} Run query <kbd>Ctrl ↵</kbd>
        </button>
      </div>
      <div className="examples"><span className="eyebrow">Try an example</span><div className="example-grid">
        {samples.map(({ kind, icon: Icon, text }) => <button key={kind} type="button" className="example" title={text}
          onClick={() => { setQuestion(text); setRoute('auto'); setGenerator('local'); submit(text, 'auto', 'local') }}>
          <Icon size={16} /><span><strong>{kind}</strong><small>{text}</small></span><ArrowUpRight size={15} />
        </button>)}
      </div></div>
    </form>
    <div className="output-grid"><Results result={result} pending={pending} error={error} openPaper={openPaper} />
      <Evidence result={result} status={status} /></div>
  </div>
}

function PaperLibrary({ status, openPaper }) {
  const [term, setTerm] = useState('')
  const [q, setQ] = useState('')
  const [year, setYear] = useState('')
  const [topic, setTopic] = useState('')
  const [offset, setOffset] = useState(0)
  const { data: topics } = useResource('/trends')
  const params = new URLSearchParams({ q, offset, ...(year ? { year } : {}), ...(topic ? { topic } : {}) })
  const { data, error, loading } = useResource(`/papers?${params}`)
  const start = status?.totals?.year_from ?? 2018
  const end = status?.totals?.year_to ?? 2024
  const years = Array.from({ length: Math.min(321, end - start + 1) }, (_, i) => end - i)
  return <>
    <PageHeader label="Corpus" title="Paper library" text="Browse the records ScholarQL can query and open their abstracts and source links." />
    <section className="panel">
      <form className="library-controls" onSubmit={(e) => { e.preventDefault(); setQ(term); setOffset(0) }}>
        <label><span>Find a paper</span><div className="search-field"><Search size={17} /><input value={term} maxLength={150}
          onChange={(e) => setTerm(e.target.value)} placeholder="Title or arXiv ID" /></div></label>
        <label>Year<select value={year} onChange={(e) => { setYear(e.target.value); setOffset(0) }}>
          <option value="">All years</option>{years.map((y) => <option key={y}>{y}</option>)}</select></label>
        <label>Topic<select value={topic} onChange={(e) => { setTopic(e.target.value); setOffset(0) }}>
          <option value="">All topics</option>{topics?.topics?.map((t) => <option key={t.topic_id} value={t.topic_id}>{t.name}</option>)}</select></label>
        <button className="primary-button" type="submit"><Search size={16} /> Search</button>
      </form>
      {loading ? <Busy /> : error ? <div className="notice">{error}</div> : <>
        <div className="panel-title"><h2>{format(data.total)} {data.total === 1 ? 'paper' : 'papers'}</h2></div>
        {data.items.length ? <div className="library-grid">
          {data.items.map((p) => <article key={p.paper_id} className="library-item">
            <div className="paper-meta">{p.publication_year ?? '—'} {p.arxiv_id && `· arXiv:${p.arxiv_id}`}</div>
            <button className="paper-title" onClick={() => openPaper(p.paper_id)}>{p.title}<ArrowUpRight size={16} /></button>
            <div className="library-foot"><span>{p.venue ?? 'Venue unavailable'}</span><Badge tone="plain">{p.cited_by_count} in-corpus cites</Badge></div>
          </article>)}
        </div> : <Empty>No papers match these filters.</Empty>}
        {data.total > data.limit && <div className="pager">
          <button className="secondary-button" disabled={offset === 0} onClick={() => setOffset(Math.max(0, offset - data.limit))}><ArrowLeft size={16} /> Previous</button>
          <span>Showing {offset + 1}–{Math.min(offset + data.limit, data.total)} of {format(data.total)}</span>
          <button className="secondary-button" disabled={offset + data.limit >= data.total} onClick={() => setOffset(offset + data.limit)}>Next <ArrowRight size={16} /></button>
        </div>}
      </>}
    </section>
  </>
}

function Details({ paperId, close, goGraph }) {
  const { data, error, loading } = useResource(paperId ? `/papers/${encodeURIComponent(paperId)}` : null)
  const dialog = useRef(null)
  useEffect(() => {
    if (dialog.current && !dialog.current.open) dialog.current.showModal()
  }, [])
  const arxiv = arxivHref(data?.arxiv_id)
  const openalex = /^W\d+$/.test(paperId) ? `https://openalex.org/${paperId}` : null
  return <dialog className="details" ref={dialog} onCancel={(e) => { e.preventDefault(); close() }} onClick={(e) => { if (e.target === dialog.current) close() }}>
    <div className="detail-inner">
      <div className="panel-title"><div><BookOpen size={19} /><h2>Paper record</h2></div>
        <button className="icon-button" aria-label="Close paper record" onClick={close}><X size={22} /></button></div>
      {loading && <Busy />}
      {error && <div className="notice">{error}</div>}
      {data && <div className="detail-content">
        <div className="paper-meta">{data.publication_year ?? '—'} · {data.venue ?? 'Venue unavailable'}</div>
        <h3>{data.title}</h3><p className="author-list">{data.authors.map((a) => a.name).join(', ')}</p>
        <div className="detail-tags">{data.topics.map((topic) => <Badge key={topic}>{topic}</Badge>)}</div>
        <dl className="facts"><div><dt>Identifier</dt><dd>{data.paper_id}</dd></div>
          <div><dt>Incoming citations in corpus</dt><dd>{format(data.cited_by_count)}</dd></div>
          {data.doi && <div><dt>DOI</dt><dd>{data.doi}</dd></div>}</dl>
        <h4>Abstract</h4><p>{data.abstract || (data.content_status === 'unavailable' ? 'The document store is unavailable.' : 'No abstract is available in the current corpus.')}</p>
        {data.tldr?.text && <><h4>Semantic Scholar summary</h4><p>{data.tldr.text}</p></>}
        <div className="detail-actions">
          {arxiv && <a className="secondary-button" href={arxiv} target="_blank" rel="noreferrer">Open on arXiv <ArrowUpRight size={16} /></a>}
          {openalex && <a className="secondary-button" href={openalex} target="_blank" rel="noreferrer">OpenAlex <ArrowUpRight size={16} /></a>}
          <button className="primary-button" onClick={() => goGraph(data.paper_id)}><Network size={16} /> Explore citations</button>
        </div>
      </div>}
    </div>
  </dialog>
}

function CitationDiagram({ graph, go, openPaper }) {
  const canvas = useRef(null)
  const board = useRef(null)
  const nodes = new Map([[graph.root.paper_id, { id: graph.root.paper_id, name: graph.root.title, depth: 0 }]])
  const edges = graph.edges.map((edge) => {
    const [from, to] = graph.direction === 'outgoing' ? [edge.citing_id, edge.cited_id] : [edge.cited_id, edge.citing_id]
    nodes.set(from, { id: from, name: edge.from_title, depth: edge.from_level })
    nodes.set(to, { id: to, name: edge.to_title, depth: edge.to_level })
    return { from, to }
  })
  const levels = Object.groupBy(nodes.values(), (node) => node.depth)
  const visible = Object.values(levels).map((list) => list.slice(0, 12))
  useEffect(() => {
    const anchor = board.current
    const sheet = canvas.current
    const draw = () => {
      const rect = anchor.getBoundingClientRect()
      const ratio = window.devicePixelRatio || 1
      sheet.width = Math.max(1, rect.width * ratio)
      sheet.height = Math.max(1, rect.height * ratio)
      const ctx = sheet.getContext('2d')
      ctx.scale(ratio, ratio)
      const positions = new Map([...anchor.querySelectorAll('[data-node]')].map((node) => [node.dataset.node, node.getBoundingClientRect()]))
      ctx.strokeStyle = '#9caef0'
      ctx.lineWidth = 1.2
      for (const edge of edges) {
        const from = positions.get(edge.from), to = positions.get(edge.to)
        if (!from || !to) continue
        const x1 = from.right - rect.left, y1 = from.top + from.height / 2 - rect.top
        const x2 = to.left - rect.left, y2 = to.top + to.height / 2 - rect.top
        const cx = (x1 + x2) / 2
        ctx.beginPath(); ctx.moveTo(x1, y1); ctx.bezierCurveTo(cx, y1, cx, y2, x2, y2); ctx.stroke()
      }
    }
    const observer = new ResizeObserver(draw)
    observer.observe(anchor)
    draw()
    return () => observer.disconnect()
  }, [graph])
  return <>
    <div className="graph-scroll"><div ref={board} className="graph-board" style={{ '--levels': visible.length }}>
      <canvas ref={canvas} aria-hidden="true" />
      {visible.map((level, i) => <div className="graph-column" key={i}>
        <div className="graph-label">{i === 0 ? 'Starting paper' : `Hop ${i}`}{i > 0 ? ` · ${levels[i].length}` : ''}</div>
        {level.map((node) => <button key={node.id} className={`graph-node ${i === 0 ? 'graph-root' : ''}`}
          data-node={node.id} title={node.name} onClick={() => i === 0 ? openPaper(node.id) : go(node.id)}>
          <small>{node.id}</small><span>{node.name}</span>{i > 0 && <ArrowUpRight size={14} />}</button>)}
      </div>)}
    </div></div>
    {visible.some((list, i) => levels[i].length > list.length) && <p className="table-note">The diagram shows up to 12 papers per hop. See the edge table for the returned relationships.</p>}
  </>
}
function Citations({ root, setRoot, openPaper }) {
  const [term, setTerm] = useState(root)
  const [depth, setDepth] = useState(2)
  const [direction, setDirection] = useState('outgoing')
  const [searchError, setSearchError] = useState('')
  const { data, error, loading } = useResource(`/citations/${encodeURIComponent(root)}?depth=${depth}&direction=${direction}`)
  function go(id) { setRoot(id); setTerm(id); setSearchError('') }
  async function find(e) {
    e.preventDefault()
    const termClean = term.trim()
    if (!termClean) return
    if (/^(W\d+|arxiv:\d{4}\.\d{4,5})$/i.test(termClean)) { go(termClean.startsWith('arxiv') ? termClean : termClean.toUpperCase()); return }
    try {
      const res = await api(`/papers?${new URLSearchParams({ q: termClean, limit: 1 })}`)
      if (!res.items.length) { setSearchError('No paper matched that title or identifier.'); return }
      go(res.items[0].paper_id)
    } catch (err) { setSearchError(err.message) }
  }
  return <>
    <PageHeader label="Citation graph" title="Follow the citations" text="Trace references and citing papers through the observed edges in the current corpus." />
    <section className="panel">
      <form className="library-controls" onSubmit={find}>
        <label><span>Starting paper</span><div className="search-field"><Search size={17} /><input value={term} maxLength={150}
          onChange={(e) => setTerm(e.target.value)} placeholder="Paper title, arXiv ID, or OpenAlex ID" /></div></label>
        <label>Direction<select value={direction} onChange={(e) => setDirection(e.target.value)}>
          <option value="outgoing">References</option><option value="incoming">Cited by</option></select></label>
        <label>Depth<select value={depth} onChange={(e) => setDepth(Number(e.target.value))}>
          {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} {n === 1 ? 'hop' : 'hops'}</option>)}</select></label>
        <button className="primary-button" type="submit"><Network size={16} /> Explore</button>
      </form>
      {searchError && <div className="notice">{searchError}</div>}
      {loading ? <Busy /> : error ? <div className="notice">{error}</div> : <>
        <div className="panel-title"><h2>{data.root.title}</h2><Badge>{data.edges.length} edges</Badge></div>
        <CitationDiagram graph={data} go={go} openPaper={openPaper} />
        {!data.edges.length ? <Empty icon={Network}>No {direction === 'outgoing' ? 'references' : 'incoming citations'} were observed in this corpus.</Empty> :
          <details className="edge-details"><summary>View citation edges {data.truncated ? '(first 120)' : ''}</summary>
            <DataTable columns={direction === 'outgoing' ? ['hop', 'citing_paper', 'cited_paper'] : ['hop', 'cited_paper', 'citing_paper']}
             rows={data.edges.map((e) => [e.to_level, e.from_title, e.to_title])} /></details>}
      </>}
    </section>
  </>
}

function Trends() {
  const [topic, setTopic] = useState('')
  const { data, error, loading } = useResource(topic ? `/trends?${new URLSearchParams({ topic })}` : '/trends')
  const [topics, setTopics] = useState([])
  useEffect(() => { if (data?.topics) setTopics(data.topics) }, [data])
  const scale = Math.max(1, ...((data?.items ?? []).map((row) => row.paper_count)))
  return <>
    <PageHeader label="Corpus analytics" title="Publication trends" text="Count papers by first arXiv submission year and category in the selected corpus." />
    <section className="panel">
      <div className="panel-title"><h2>Annual volume</h2><label className="inline-control">Topic<select value={topic} onChange={(e) => setTopic(e.target.value)}>
        <option value="">All papers</option>{topics.map((t) => <option key={t.topic_id} value={t.topic_id}>{t.name}</option>)}
      </select></label></div>
      {loading ? <Busy /> : error ? <div className="notice">{error}</div> : !data.items.length ? <Empty>No records for this topic.</Empty> :
        <div className="bars">{data.items.map((row) => <div key={row.publication_year} className="bar-row">
          <span>{row.publication_year}</span><div className="bar-track"><div style={{ width: `${row.paper_count / scale * 100}%` }} /></div>
          <strong>{format(row.paper_count)}</strong></div>)}</div>}
    </section>
  </>
}

function Evaluation() {
  const { data, error, loading } = useResource('/artifacts/evaluation')
  const [tab, setTab] = useState('sql')
  const studies = data?.sql?.studies
  const retrieval = data?.retrieval?.summaries
  const indexes = data?.indexes?.rows
  const hybrid = retrieval?.hybrid
  return <>
    <PageHeader label="Reproducibility" title="Evaluation lab" text="Inspect execution accuracy, retrieval quality, and PostgreSQL plans from the frozen experiments." />
    {loading ? <Busy /> : error ? <div className="notice">{error}</div> : <>
      <div className="evaluation-tiles">
        <article className="panel"><Database size={20} /><span>SQL questions</span><strong>{format(studies?.local?.overall?.n)}</strong><small>Four query tiers</small></article>
        <article className="panel"><Layers3 size={20} /><span>Retrieval questions</span><strong>{format(data.retrieval?.metadata?.questions)}</strong><small>On the arXiv pilot</small></article>
        <article className="panel"><BarChart3 size={20} /><span>PostgreSQL workload</span><strong>{format(data.indexes?.metadata?.counts?.paper)}</strong><small>Synthetic papers</small></article>
      </div>
      <div className="section-tabs" role="group" aria-label="Experiment">
        {[['sql','SQL execution'], ['retrieval','Document retrieval'], ['indexes','PostgreSQL indexes']].map(([id, name]) =>
          <button key={id} aria-pressed={tab === id} className={tab === id ? 'selected' : ''} onClick={() => setTab(id)}>{name}</button>)}</div>
      {tab === 'sql' && <section className="panel">
        <div className="panel-title"><h2>Execution across two snapshots</h2><div><LinkFile name="benchmark">Questions + gold SQL</LinkFile><LinkFile name="sql">Per-question CSV</LinkFile></div></div>
        <p className="panel-note">An answer passes when its result matches the gold query on the arXiv pilot and the counterfactual fixture.</p>
        <DataTable columns={['tier', 'questions', 'correct_on_both', 'p95_ms']}
          rows={Object.entries(studies?.local?.tiers ?? {}).map(([tier, m]) => [rowLabel(tier), m.n, m.joint_correct, number(m.p95_ms)])} />
        {studies?.local && <div className="bench-note">
          <span>Canonical wording <strong>{studies.local.wording.canonical.joint_correct}/{studies.local.wording.canonical.n}</strong></span>
          <span>Paraphrases <strong>{studies.local.wording.paraphrase.joint_correct}/{studies.local.wording.paraphrase.n}</strong></span>
          <span>Engine <strong>{data.sql.primary_engine}</strong></span>
        </div>}
        {Object.keys(studies ?? {}).length === 1 && <p className="table-note">The recorded run uses the local compiler. Gemini and Groq ablations require a configured model and credentials.</p>}
      </section>}
      {tab === 'retrieval' && <section className="panel">
        <div className="panel-title"><h2>Hybrid retrieval at rank 5</h2><div><LinkFile name="qrels">Relevance labels</LinkFile><LinkFile name="retrieval">Per-query CSV</LinkFile></div></div>
        <p className="panel-note">Recall and relevance use the pilot judgments. Eligibility checks whether each returned paper meets the metadata constraints.</p>
        <DataTable columns={['ranking_method', 'recall_at_5', 'ndcg_at_5', 'eligible_results', 'p95_ms']}
          rows={Object.entries(hybrid ?? {}).map(([name, m]) => [rowLabel(name), number(m.recall, 3), number(m.ndcg, 3),
             `${number(m.eligibility * 100, 1)}%`, number(m.p95_ms)])} />
      </section>}
      {tab === 'indexes' && <section className="panel">
        <div className="panel-title"><h2>Median query latency</h2><div><LinkFile name="plans">EXPLAIN plans</LinkFile><LinkFile name="timings">Raw timings</LinkFile></div></div>
        <p className="panel-note">Warm-cache measurements with {data.indexes?.metadata?.repetitions_per_query_and_condition} repetitions per query and condition. All results matched across conditions.</p>
        <DataTable columns={['query', 'baseline_ms', 'indexed_ms', 'baseline_over_indexed']}
          rows={(indexes ?? []).map((m) => [rowLabel(m.query), number(m.baseline_median_ms, 3), number(m.indexed_median_ms, 3), `${number(m.speedup)}×`])} />
      </section>}
    </>}
  </>
}
function QueryHistory({ edit }) {
  const { data, error, loading } = useResource('/history')
  return <>
    <PageHeader label="Query history" title="Recent questions" text="Reopen a previous question and review its route and execution status." />
    <section className="panel">
      {loading ? <Busy /> : error ? <div className="notice">{error}</div> : !data.items.length ? <Empty icon={History}>There are no saved questions yet.</Empty> :
        data.items.map((item, i) => <div key={i} className="history-row">
          <div><span className="paper-meta">{routes[item.route]} · {item.status.replaceAll('_',' ')} · {number(item.latency_ms)} ms</span>
            <p>{item.question}</p></div>
          <button className="secondary-button small-button" onClick={() => edit(item.question)}>Reopen <ArrowUpRight size={15} /></button>
        </div>)}
    </section>
  </>
}

function currentPage() {
  const page = window.location.hash.replace(/^#\/?/, '')
  return nav.some(([id]) => id === page) ? page : 'workbench'
}
function App() {
  const { data: status, error: statusError } = useResource('/status')
  const [page, setPage] = useState(currentPage)
  const [paperId, setPaperId] = useState(null)
  const [root, setRoot] = useState(graphRoot)
  const [edit, setEdit] = useState(null)
  useEffect(() => {
    const change = () => setPage(currentPage())
    window.addEventListener('hashchange', change)
    return () => window.removeEventListener('hashchange', change)
  }, [])
  function navigate(id) { window.location.hash = id; setPage(id); window.scrollTo(0, 0) }
  function graphFor(id) { setRoot(id); setPaperId(null); navigate('citations') }
  function reopen(text) { navigate('workbench'); setEdit({ text }) }
  return <div className="shell">
    <a className="skip-link" href="#main-content" onClick={(e) => { e.preventDefault(); document.getElementById('main-content').focus() }}>Skip to content</a>
    <aside className="rail">
      <a href="#workbench" className="brand" onClick={() => navigate('workbench')}><Mark /><span>Scholar<span>QL</span></span></a>
      <nav aria-label="Workspace">{nav.map(([id, name, Icon]) => <a key={id} href={`#${id}`} title={name}
        onClick={() => navigate(id)} className={page === id ? 'active' : ''} aria-label={name} aria-current={page === id ? 'page' : undefined}>
        <Icon size={18} /><span>{name}</span>{page === id && <ArrowRight className="rail-active-arrow" size={14} />}
      </a>)}</nav>
      <div className="rail-data">
        <div className="rail-data-title"><Database size={17} /><span>{status?.corpus ?? 'Corpus'}</span></div>
        {status ? <><div className="rail-stat"><strong>{format(status.totals.papers)}</strong><span>Papers</span></div>
          <div className="rail-stat"><strong>{format(status.totals.citations)}</strong><span>Citation edges</span></div></> :
          <span className="rail-caption">{statusError ? 'Database unavailable' : 'Connecting…'}</span>}
      </div>
    </aside>
    <div className="workspace">
      <header className="topbar"><span><span className="topbar-parent">Workspace</span><span className="topbar-divider">/</span>{nav.find(([id]) => id === page)[1]}</span>
        <div className="system-status"><span className={`connection ${status ? 'connected' : ''}`} />
          {status ? `${status.relational} · ${status.documents}` : statusError ? 'Backend unavailable' : 'Connecting…'}</div></header>
      <main id="main-content" tabIndex="-1" className="main">
        {statusError && <div className="notice" role="alert">{statusError}</div>}
        <Workbench status={status} openPaper={setPaperId} active={page === 'workbench'} edit={edit} />
        {page === 'papers' && <PaperLibrary status={status} openPaper={setPaperId} />}
        {page === 'citations' && <Citations root={root} setRoot={setRoot} openPaper={setPaperId} />}
        {page === 'trends' && <Trends />}
        {page === 'evaluation' && <Evaluation />}
        {page === 'history' && <QueryHistory edit={reopen} />}
      </main>
      {paperId && <Details key={paperId} paperId={paperId} close={() => setPaperId(null)} goGraph={graphFor} />}
    </div>
  </div>
}

createRoot(document.getElementById('root')).render(<App />)
