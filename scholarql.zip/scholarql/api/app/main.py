from contextlib import asynccontextmanager

from fastapi import FastAPI

from app.db import lifespan_pool, pool
from app.routers import citations, papers, trends


@asynccontextmanager
async def lifespan(_: FastAPI):
    async with lifespan_pool():
        yield


app = FastAPI(title="ScholarQL API", version="0.1.0", lifespan=lifespan)
app.include_router(papers.router)
app.include_router(citations.router)
app.include_router(trends.router)


@app.get("/health", tags=["system"])
async def health():
    async with pool.connection() as connection:
        await (await connection.execute("SELECT 1")).fetchone()
    return {"status": "ok", "database": "ok"}
