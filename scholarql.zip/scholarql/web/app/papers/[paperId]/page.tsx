import Link from "next/link";
import { notFound } from "next/navigation";

const api = process.env.SCHOLARQL_API_URL ?? "http://127.0.0.1:8000";

type Paper = {
  paper_id: string; title: string; publication_year: number | null; publication_date: string | null;
  doi: string | null; arxiv_id: string | null; cited_by_count: number; pagerank_score: number;
  venue: string | null; authors: { author_id: string; name: string }[];
  topics: { topic_id: string; name: string; relevance: number | null }[];
};

export default async function PaperPage({ params }: { params: Promise<{ paperId: string }> }) {
  const { paperId } = await params;
  const response = await fetch(`${api}/papers/${encodeURIComponent(paperId)}`, { next: { revalidate: 60 } });
  if (response.status === 404) notFound();
  if (!response.ok) throw new Error("Could not load this paper");
  const paper: Paper = await response.json();
  return (
    <article>
      <div className="eyebrow">Paper record</div>
      <h1>{paper.title}</h1>
      <p className="lede">{paper.authors.map((author) => author.name).join(", ") || "Author information unavailable"}</p>
      <div className="stat-grid">
        <div className="stat"><span>Year</span><strong>{paper.publication_year ?? "Unknown"}</strong></div>
        <div className="stat"><span>Venue</span><strong>{paper.venue ?? "Unknown"}</strong></div>
        <div className="stat"><span>In-scope citations</span><strong>{paper.cited_by_count}</strong></div>
        <div className="stat"><span>PageRank</span><strong>{paper.pagerank_score.toPrecision(4)}</strong></div>
      </div>
      <section className="content-section">
        <h2>Topics</h2>
        <div className="chips">{paper.topics.map((topic) => <span className="chip" key={topic.topic_id}>{topic.name}</span>)}</div>
      </section>
      <section className="content-section">
        <h2>Identifiers</h2>
        <p className="metadata">OpenAlex: {paper.paper_id}</p>
        {paper.arxiv_id && <p className="metadata">arXiv: {paper.arxiv_id}</p>}
        {paper.doi && <p className="metadata">DOI: {paper.doi}</p>}
      </section>
      <Link className="button-link" href={`/citations/${encodeURIComponent(paper.paper_id)}`}>Explore citation chain</Link>
    </article>
  );
}
