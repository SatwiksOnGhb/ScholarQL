@echo off
setlocal
cd /d "%~dp0"
if exist ".venv\Scripts\python.exe" goto install
py -3.11 -m venv .venv
if exist ".venv\Scripts\python.exe" goto install
py -3.12 -m venv .venv
if exist ".venv\Scripts\python.exe" goto install
python -m venv .venv
if not exist ".venv\Scripts\python.exe" goto failed
:install
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed
".venv\Scripts\python.exe" run.py --open
if errorlevel 1 goto failed
exit /b 0
:failed
echo ScholarQL could not start. Install Python 3.11 or 3.12 and check the terminal message above.
pause
exit /b 1
