# Person A report chapter: relational core

## Design goals

The relational store is the source of truth for entity identifiers, paper metadata, authorship, affiliations, topics, and in-scope citation edges. OpenAlex IDs are stored as text so the same IDs can link documents in MongoDB. Long-form abstracts, TLDRs, and vectors are passed to the NoSQL layer through `papers_content.jsonl`.

## ER design and normalization

```mermaid
erDiagram
    VENUE ||--o{ PAPER : publishes
    PAPER ||--o{ AUTHORSHIP : has
    AUTHOR ||--o{ AUTHORSHIP : writes
    AUTHORSHIP ||--o{ AUTHOR_AFFILIATION : links
    INSTITUTION ||--o{ AUTHOR_AFFILIATION : hosts
    PAPER ||--o{ PAPER_TOPIC : tagged
    TOPIC ||--o{ PAPER_TOPIC : classifies
    TOPIC o|--o{ TOPIC : parent_of
    PAPER ||--o{ CITATION : cites
    PAPER ||--o{ CITATION : cited_by
```

The design is in third normal form. Each entity's descriptive attributes depend on its key: venue details live in `venue`, author details in `author`, and topic hierarchy names in `topic`. Many-to-many relations are represented by `authorship`, `paper_topic`, and `citation`. Affiliations are tied to an author-paper authorship because institutions may differ across an author's papers. Multi-valued authors, topics, and references are not stored as delimited attributes in the relational tables.

`paper` has one row per canonical OpenAlex work. Partial unique indexes on DOI and arXiv ID enforce the deduplication policy where those identifiers exist. Papers missing either identifier remain valid because these values are nullable. `citation` includes only links for which both endpoints were selected into the corpus. Its composite primary key prevents duplicate directed edges.

## Ingestion and source lineage

The data window is first submissions during 2018-2024 in arXiv categories `cs.LG` or `cs.AI`. `fetch_arxiv_manifest.py` records the category membership and first submission date. This membership list is important because OpenAlex's topic hierarchy is a different classification and cannot prove arXiv category inclusion.

OpenAlex supplies the normalized entities, work metadata, topic hierarchy, and references. The pipeline deduplicates OpenAlex records by normalized DOI or arXiv ID and rewrites reference identifiers to the selected canonical record. The API key is read from `OPENALEX_API_KEY`, never stored in this repository. Semantic Scholar enrichment is optional and best effort: `enrich_semantic_scholar.py` retrieves TLDRs and references, while the loader maps those references into the in-corpus graph where an arXiv ID or DOI matches.

The `load_openalex.py` process writes normalized entities in batches of 500 in a transaction per batch. It sets citation counts to zero and derives the project's in-scope counts from the citation graph. It then bulk-loads distinct citation edges and recomputes PageRank and the analytics views. Re-running the loader is safe for entity rows because insert conflicts update the canonical metadata; citation edges use `ON CONFLICT DO NOTHING`.

## Database features

- Constraints enforce non-empty titles and names, valid publication years, non-negative counts, valid venue types, uniqueness of author order per paper, and valid foreign-key relationships.
- Trigram GIN indexes support fuzzy matching of author, venue, and paper-title strings. Exact IDs remain the join keys.
- `citation_chain(paper_id, depth)` uses a recursive query with cycle protection and a 20-edge maximum.
- `coauthors(author_id)` supports the reviewer finder conflict check.
- A citation trigger maintains in-corpus citation counts. A PL/pgSQL `compute_pagerank` procedure runs a bounded iterative PageRank calculation over the directed citation graph.
- Materialized views provide topic-by-year counts and author statistics. `refresh_analytics()` refreshes them after an ingest batch.
- `scholarql_reader` receives `SELECT` access only, plus an eight-second statement timeout and read-only default transactions.

## Performance study method

`db/bench/performance.sql` contains ten representative plans for lookup, join, fuzzy name linking, citation traversal, trend aggregation, author counts, DOI lookup, incoming citations, institution collaboration, and venue/year totals. Compare the baseline and indexed conditions on the same loaded dataset and database instance. Save JSON `EXPLAIN (ANALYZE, BUFFERS)` plans, record the PostgreSQL version, hardware, row counts, and cache state, and repeat each timed query at least 30 times. `latency_benchmark.py` reports median and p95 latency in milliseconds for each condition.

No performance numbers are included here yet: they must be measured on the final 50K-paper dataset and target machine. `EXPLAIN ANALYZE` executes its statement, so benchmark only the read-only queries in the supplied script.

## Schema validation

The migration was applied to a temporary PostgreSQL 18 database, the sample seed loaded, and the down migration exercised. Checks passed for the citation-count trigger, recursive citation function, coauthor function, PageRank score normalization, analytics-view refresh, and reader-role `SELECT` access. A reader `INSERT` was rejected. The temporary database was stopped and removed. The full OpenAlex harvest, API/UI integration, and 50K performance study have not been run.

## A-owned API and interface

The FastAPI routes provide paper search/detail, recursive citations, and topic trends. The Next.js pages consume those endpoints for the paper list/detail, citation explorer, and topic trend table. The rest of the group should merge these slices into the shared application shell after the OpenAPI contract is frozen; the `/papers`, `/citations`, and `/trends` response shapes are visible in FastAPI's generated OpenAPI document.
