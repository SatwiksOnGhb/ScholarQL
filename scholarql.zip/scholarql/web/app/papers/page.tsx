import Link from "next/link";

type Paper = {
  paper_id: string;
  title: string;
  publication_year: number | null;
  venue: string | null;
  cited_by_count: number;
  authors: { author_id: string; name: string }[];
};

type Result = { items: Paper[]; total: number };
const api = process.env.SCHOLARQL_API_URL ?? "http://127.0.0.1:8000";

export default async function PapersPage({ searchParams }: { searchParams: Promise<{ q?: string; year?: string }> }) {
  const params = await searchParams;
  const q = params.q?.trim() ?? "";
  const year = params.year?.trim() ?? "";
  const query = new URLSearchParams({ limit: "50" });
  if (q) query.set("q", q);
  if (year && /^\d{4}$/.test(year)) {
    query.set("year_from", year);
    query.set("year_to", year);
  }

  let result: Result | null = null;
  let error = "";
  try {
    const response = await fetch(`${api}/papers?${query.toString()}`, { next: { revalidate: 60 } });
    if (!response.ok) throw new Error(`Paper API returned ${response.status}`);
    result = await response.json();
  } catch {
    error = "The paper service is not available. Start the API and load the relational dataset.";
  }

  return (
    <section>
      <div className="eyebrow">Research literature</div>
      <h1>Explore papers</h1>
      <p className="lede">Search the structured paper collection and follow its citation links.</p>
      <form className="filters" action="/papers">
        <label>Title contains<input name="q" defaultValue={q} placeholder="e.g. graph learning" /></label>
        <label>Year<input name="year" inputMode="numeric" defaultValue={year} placeholder="2022" /></label>
        <button type="submit">Search papers</button>
      </form>
      {error && <p className="notice" role="status">{error}</p>}
      {result && <p className="result-count">{result.total.toLocaleString()} papers found</p>}
      <div className="paper-list">
        {result?.items.map((paper) => (
          <article className="paper-card" key={paper.paper_id}>
            <h2><Link href={`/papers/${encodeURIComponent(paper.paper_id)}`}>{paper.title}</Link></h2>
            <p className="muted">{paper.authors.map((author) => author.name).join(", ") || "Author information unavailable"}</p>
            <p className="metadata">{paper.publication_year ?? "Year unknown"} · {paper.venue ?? "Venue unknown"} · {paper.cited_by_count} in-scope citations</p>
            <Link className="text-link" href={`/citations/${encodeURIComponent(paper.paper_id)}`}>Open citation explorer →</Link>
          </article>
        ))}
      </div>
    </section>
  );
}
