import type { Metadata } from "next";
import type { ReactNode } from "react";
import Link from "next/link";
import "./styles.css";

export const metadata: Metadata = {
  title: "ScholarQL",
  description: "Explore papers, citations, and research topic trends.",
};

export default function RootLayout({ children }: Readonly<{ children: ReactNode }>) {
  return (
    <html lang="en">
      <body>
        <header className="topbar">
          <Link className="brand" href="/papers">ScholarQL</Link>
          <nav aria-label="Main navigation">
            <Link href="/papers">Papers</Link>
            <Link href="/trends">Topic trends</Link>
          </nav>
        </header>
        <main className="container">{children}</main>
      </body>
    </html>
  );
}
