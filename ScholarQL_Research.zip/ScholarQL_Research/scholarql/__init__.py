"""ScholarQL research workbench."""
