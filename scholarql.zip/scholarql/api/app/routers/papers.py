from fastapi import APIRouter, HTTPException, Query

from app.db import pool

router = APIRouter(prefix="/papers", tags=["papers"])


@router.get("")
async def list_papers(
    q: str | None = None,
    year_from: int | None = Query(default=None, ge=1800, le=2100),
    year_to: int | None = Query(default=None, ge=1800, le=2100),
    venue_id: str | None = None,
    author: str | None = None,
    limit: int = Query(default=25, ge=1, le=100),
    offset: int = Query(default=0, ge=0),
):
    if year_from and year_to and year_from > year_to:
        raise HTTPException(status_code=422, detail="year_from must be <= year_to")
    clauses: list[str] = []
    params: list[object] = []
    if q:
        clauses.append("p.title ILIKE %s")
        params.append(f"%{q}%")
    if year_from is not None:
        clauses.append("p.publication_year >= %s")
        params.append(year_from)
    if year_to is not None:
        clauses.append("p.publication_year <= %s")
        params.append(year_to)
    if venue_id:
        clauses.append("p.venue_id = %s")
        params.append(venue_id)
    if author:
        clauses.append("EXISTS (SELECT 1 FROM authorship au JOIN author a USING (author_id) WHERE au.paper_id = p.paper_id AND a.name % %s)")
        params.append(author)
    where = "WHERE " + " AND ".join(clauses) if clauses else ""
    sql = f"""
        SELECT p.paper_id, p.title, p.publication_year, p.publication_date, p.doi,
               p.arxiv_id, p.cited_by_count, p.pagerank_score, v.name AS venue,
               count(*) OVER() AS total_count,
               coalesce((SELECT jsonb_agg(jsonb_build_object('author_id', a.author_id, 'name', a.name) ORDER BY au.author_order)
                         FROM authorship au JOIN author a USING (author_id)
                         WHERE au.paper_id = p.paper_id), '[]'::jsonb) AS authors
        FROM paper p LEFT JOIN venue v USING (venue_id)
        {where}
        ORDER BY p.publication_year DESC NULLS LAST, p.cited_by_count DESC, p.paper_id
        LIMIT %s OFFSET %s
    """
    async with pool.connection() as connection:
        rows = await (await connection.execute(sql, [*params, limit, offset])).fetchall()
    total = rows[0]["total_count"] if rows else 0
    for row in rows:
        row.pop("total_count", None)
    return {"items": rows, "total": total, "limit": limit, "offset": offset}


@router.get("/{paper_id}")
async def get_paper(paper_id: str):
    async with pool.connection() as connection:
        row = await (await connection.execute(
            """SELECT p.paper_id, p.title, p.publication_year, p.publication_date, p.doi,
                      p.arxiv_id, p.cited_by_count, p.pagerank_score, v.name AS venue,
                      coalesce((SELECT jsonb_agg(jsonb_build_object('author_id', a.author_id, 'name', a.name) ORDER BY au.author_order)
                                FROM authorship au JOIN author a USING (author_id) WHERE au.paper_id = p.paper_id), '[]'::jsonb) AS authors,
                      coalesce((SELECT jsonb_agg(jsonb_build_object('topic_id', t.topic_id, 'name', t.name, 'relevance', pt.relevance)
                                ORDER BY pt.is_primary DESC, pt.relevance DESC NULLS LAST)
                                FROM paper_topic pt JOIN topic t USING (topic_id) WHERE pt.paper_id = p.paper_id), '[]'::jsonb) AS topics
               FROM paper p LEFT JOIN venue v USING (venue_id) WHERE p.paper_id = %s""",
            (paper_id,),
        )).fetchone()
    if row is None:
        raise HTTPException(status_code=404, detail="Paper not found")
    return row
